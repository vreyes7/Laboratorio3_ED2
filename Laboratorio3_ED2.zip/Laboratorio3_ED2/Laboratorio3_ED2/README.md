# Laboratorio3_ED2
Debido a que no funcionaba en el editor de texto de Visual Studio se transfirio
a un block de notas. El problema era que por seguridad del equipo no permit�a
ejecutar el script dentro del c�digo.