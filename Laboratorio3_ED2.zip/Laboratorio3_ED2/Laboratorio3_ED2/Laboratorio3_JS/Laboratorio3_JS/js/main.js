﻿// Your code here!

    var json_elementos = {};
console.log("hola");
        function agregarObjeto() {
            var llave = document.getElementById(_llave);
            var valor = document.getElementById(_valor);
            json_elementos.push({ llave : valor });

            
        }


